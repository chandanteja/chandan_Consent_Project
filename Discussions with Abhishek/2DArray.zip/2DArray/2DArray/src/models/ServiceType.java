package models;

public enum ServiceType {
    OPD,
    SURGERY
}
