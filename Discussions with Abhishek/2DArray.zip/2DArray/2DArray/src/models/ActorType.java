package models;

public enum ActorType {
    NURSE,
    RECEPTIONIST,
    DOCTOR,
    PHARMA
}