package models;

import java.util.List;

public class Patient {
    BasicPatient basicPatient;
    List<PatientHistory> histories;
}