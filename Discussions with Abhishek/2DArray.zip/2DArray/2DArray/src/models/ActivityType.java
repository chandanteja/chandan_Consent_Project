package models;

public enum ActivityType {
    REGISTRATION,
    VITAL_PARAMETERS,
    DOCTOR_CONSULTAION,
    DISCHARGE
}