package models;

import java.util.List;

public class PatientHistory {
    String patientId;
    String medicalCause;
}