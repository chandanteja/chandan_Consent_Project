package models;

public enum AccessLevel {
    BASIC,
    ADVANCED
}
