package models;

public class BasicPatient {
    public String id;
    String fullName;
    String fatherName;
    String dob;
    String address;
    String emailId;
    String contact;
}
