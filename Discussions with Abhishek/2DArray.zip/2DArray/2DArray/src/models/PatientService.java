package models;

public class PatientService {

    BasicPatient getBasicPatientDetails(Actor actor, String personId) {

        /*
          consent  = consentRepository.getByPersonIdAndActorId(persionId, actorId);
          check currentTime is between consent.startTime and consent.endTime;
         */
        return null;
    }




}
